export class AuthorModel{
    constructor(
          public author: String,
          public title: String,
          public genre: String,
          public image: String){}
  }