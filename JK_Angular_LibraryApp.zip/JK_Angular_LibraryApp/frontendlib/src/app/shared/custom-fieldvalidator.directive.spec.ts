import { CustomFieldvalidatorDirective } from './custom-fieldvalidator.directive';

describe('CustomFieldvalidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomFieldvalidatorDirective();
    expect(directive).toBeTruthy();
  });
});
