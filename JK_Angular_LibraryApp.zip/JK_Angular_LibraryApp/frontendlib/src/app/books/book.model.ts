export class BookModel{
  constructor(
        public title: String,
        public author: String,
        public genre: String,
        public image: String){}
}








